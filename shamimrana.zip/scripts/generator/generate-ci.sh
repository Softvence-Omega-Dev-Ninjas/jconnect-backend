#!/usr/bin/env bash

set -euo pipefail

generate_ci_workflow(){
    echo "hello"
}
