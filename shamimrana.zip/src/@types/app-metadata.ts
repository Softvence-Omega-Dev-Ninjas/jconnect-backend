export interface IAppMetadata {
    name: string;
    displayName: string;
    version: string;
    description: string;
}
