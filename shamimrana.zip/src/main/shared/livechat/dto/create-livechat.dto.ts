export class CreateLivechatDto {}
