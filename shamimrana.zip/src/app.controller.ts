import appMetadata from "@metadata/app-metadata";
import { Controller, Get, Res } from "@nestjs/common";
import { ApiOkResponse } from "@nestjs/swagger";
import type { Response } from "express";

@Controller()
export class AppController {}
